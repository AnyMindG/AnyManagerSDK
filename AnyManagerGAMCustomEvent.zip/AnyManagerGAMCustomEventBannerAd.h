//
//  AnyManagerGAMCustomEventBannerAd.h
//  Test-charboost
//
//  Created by Narender on 03/11/22.
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface AnyManagerGAMCustomEventBannerAd : NSObject
- (void)loadBannerForAdConfiguration:(GADMediationBannerAdConfiguration *)adConfiguration
                   completionHandler:(GADMediationBannerLoadCompletionHandler)completionHandler;
@end
