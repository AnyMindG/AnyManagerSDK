//
//  AnyManagerGAMCustomEventInterstitial.h
//  MyAdMobDemo
//
//  Created by Narender on 22/11/22.
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface AnyManagerGAMCustomEventInterstitial: NSObject

- (void)loadInterstitialForAdConfiguration:
            (GADMediationInterstitialAdConfiguration *)adConfiguration
                         completionHandler:
                             (GADMediationInterstitialLoadCompletionHandler)completionHandler;

@end
