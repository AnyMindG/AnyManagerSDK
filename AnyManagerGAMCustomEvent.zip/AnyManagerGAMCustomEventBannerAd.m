//
//  AnyManagerGAMCustomEventBannerAd.m
//  Test-charboost
//
//  Created by Narender on 03/11/22.
//

#import <Foundation/Foundation.h>
#import "AnyManagerGAMCustomEventBannerAd.h"
#import <GoogleMobileAds/GoogleMobileAds.h>

#import "stdatomic.h"

#define AnyManagerBannerSDKVersion  @"1.0.0"


@interface AnyManagerGAMCustomEventBannerAd ()<GADMediationBannerAd, GADBannerViewDelegate> {
    
    //deprecated: <GADCustomEventBanner>
    /// The completion handler to call when the ad loading succeeds or fails.
    GADMediationBannerLoadCompletionHandler _loadCompletionHandler;

    /// The ad event delegate to forward ad rendering events to the Google Mobile
    /// Ads SDK.
    id <GADMediationBannerAdEventDelegate> _adEventDelegate;
}

/// GAMBannerView banner.
@property(nonatomic, strong) GAMBannerView *bannerAdView;
@property (nonatomic, copy) NSString * unitId;
@property(nonatomic, strong) GAMRequest *request;
@property(nonatomic, strong) UIViewController *viewController;


@end

@implementation AnyManagerGAMCustomEventBannerAd

#pragma mark GADCustomEventBanner implementation

- (void)requestBannerAd:(GADAdSize)adSize
              parameter:(NSString *)serverParameter
                  label:(NSString *)serverLabel
                request:(GADCustomEventRequest *)request {
    // Create the bannerView with the appropriate size.
}

- (void)loadBannerForAdConfiguration:(nonnull GADMediationBannerAdConfiguration *)adConfiguration
                   completionHandler:
(nonnull GADMediationBannerLoadCompletionHandler)completionHandler{
    
    __block atomic_flag completionHandlerCalled = ATOMIC_FLAG_INIT;
     __block GADMediationBannerLoadCompletionHandler originalCompletionHandler =
         [completionHandler copy];

     _loadCompletionHandler = ^id<GADMediationBannerAdEventDelegate>(
         _Nullable id<GADMediationBannerAd> ad, NSError *_Nullable error) {
       // Only allow completion handler to be called once.
       if (atomic_flag_test_and_set(&completionHandlerCalled)) {
         return nil;
       }

       id<GADMediationBannerAdEventDelegate> delegate = nil;
       if (originalCompletionHandler) {
         // Call original handler and hold on to its return value.
         delegate = originalCompletionHandler(ad, error);
       }

       // Release reference to handler. Objects retained by the handler will also
       // be released.
       originalCompletionHandler = nil;

       return delegate;
     };
    
    NSString *parameter = adConfiguration.credentials.settings[@"parameter"];
    NSDictionary *anyManagerInfoDict = [self dictionaryWithJsonString:parameter];
    
    if ([anyManagerInfoDict objectForKey:@"unitId"]) {
        self.unitId = [anyManagerInfoDict objectForKey:@"unitId"];
    }
    
   
    
    self.viewController = adConfiguration.topViewController;
    self.request = [GAMRequest request];
    self.bannerAdView = [[GAMBannerView alloc]
                         initWithAdSize:adConfiguration.adSize];
    self.bannerAdView.adUnitID = self.unitId;
    self.bannerAdView.rootViewController = self.viewController;
    self.bannerAdView.delegate = self;
    [self.bannerAdView loadRequest: self.request];
    
}

#pragma mark -- GADMediationBannerAd

/// The banner ad view.
//@property(nonatomic, readonly, nonnull) UIView *view;
- (UIView *)view {
    return self.bannerAdView;
}

/// Tells the ad to resize the banner. Implement if banner content is resizable.
- (void)changeAdSizeTo:(GADAdSize)adSize {
    CGPoint point = _bannerAdView.frame.origin;
    self.bannerAdView.frame = CGRectMake(point.x, point.y, adSize.size.width, adSize.size.height);
}


#pragma mark -- GADBannerViewDelegate
- (void)bannerViewDidReceiveAd:(GADBannerView *)bannerView {
    _adEventDelegate = _loadCompletionHandler(self, nil);
    NSLog(@"bannerViewDidReceiveAd");
    NSLog(@"Banner adapter class name: %@", bannerView.responseInfo.adNetworkClassName);
}

- (void)bannerView:(GADBannerView *)bannerView didFailToReceiveAdWithError:(NSError *)error {
    NSLog(@"bannerView:didFailToReceiveAdWithError: %@", [error localizedDescription]);
    _adEventDelegate = _loadCompletionHandler(nil, error);
}


- (void)bannerViewDidRecordImpression:(GADBannerView *)bannerView {
    NSLog(@"bannerViewDidRecordImpression %@",  bannerView.responseInfo.adNetworkClassName);
    _adEventDelegate = _loadCompletionHandler(self, nil);
    
}

- (void)bannerViewWillPresentScreen:(GADBannerView *)bannerView {
    NSLog(@"bannerViewWillPresentScreen %@",  bannerView.responseInfo.adNetworkClassName);
    _adEventDelegate = _loadCompletionHandler(self, nil);
}

- (void)bannerViewWillDismissScreen:(GADBannerView *)bannerView {
    NSLog(@"bannerViewWillDismissScreen %@",  bannerView.responseInfo.adNetworkClassName);
    _adEventDelegate = _loadCompletionHandler(self, nil);
}

- (void)bannerViewDidDismissScreen:(GADBannerView *)bannerView {
    NSLog(@"bannerViewDidDismissScreen %@", bannerView.responseInfo.adNetworkClassName);
    _adEventDelegate = _loadCompletionHandler(self, nil);
}

- (void)bannerViewDidRecordClick:(nonnull GADBannerView *)bannerView {
    NSLog(@"bannerViewDidRecordClick %@",  bannerView.responseInfo.adNetworkClassName);
    _adEventDelegate = _loadCompletionHandler(self, nil);
}

- (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err = nil;
    id result = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err];
    
    if(err == nil && [result isKindOfClass:[NSDictionary class]]) {
        
        return result;
    }
    
    return nil;
}

+(UIWindow*)keyWindow
{
    UIWindow *foundWindow = nil;
    NSArray  *windows = [[UIApplication sharedApplication]windows];
    for (UIWindow *window in windows) {
        if (window.isKeyWindow) {
            foundWindow = window;
            break;
        }
    }
    return foundWindow;
}

@end
