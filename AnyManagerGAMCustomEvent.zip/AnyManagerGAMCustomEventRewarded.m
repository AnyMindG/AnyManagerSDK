//
//  AnyManagerGAMCustomEventRewarded.m
//  MyAdMobDemo
//
//  Created by Narender on 22/11/22.
//

#import <Foundation/Foundation.h>
#import "AnyManagerGAMCustomEventRewarded.h"
#import "stdatomic.h"
#import <GoogleMobileAds/GADInterstitialAd.h>

#define AnyManagerBannerSDKVersion  @"1.0.0"
#define KGADInterstitialAdUnitID @"/6499/example/interstitial"

@interface AnyManagerGAMCustomEventRewarded()<GADMediationRewardedAd, GADFullScreenContentDelegate> {
    
    // The completion handler to call when the ad loading succeeds or fails.
    GADMediationRewardedLoadCompletionHandler _loadCompletionHandler;
    
    /// The ad event delegate to forward ad rendering events to the Google Mobile Ads SDK.
    id <GADMediationRewardedAdEventDelegate> _adEventDelegate;
}

@property (nonatomic, copy) NSString *adUnit;
@property(nonatomic, strong) GAMRequest *request;
@property(nonatomic, strong) GADRewardedAd *rewardedAd;
@property(nonatomic, strong) UIViewController *viewController;

@end

@implementation AnyManagerGAMCustomEventRewarded

- (void)loadRewardedAdForAdConfiguration:(GADMediationRewardedAdConfiguration *)adConfiguration
                       completionHandler:
                           (GADMediationRewardedLoadCompletionHandler)completionHandler {
  __block atomic_flag completionHandlerCalled = ATOMIC_FLAG_INIT;
  __block GADMediationRewardedLoadCompletionHandler originalCompletionHandler =
      [completionHandler copy];

  _loadCompletionHandler = ^id<GADMediationRewardedAdEventDelegate>(
      _Nullable id<GADMediationRewardedAd> ad, NSError *_Nullable error) {
    // Only allow completion handler to be called once.
    if (atomic_flag_test_and_set(&completionHandlerCalled)) {
      return nil;
    }

    id<GADMediationRewardedAdEventDelegate> delegate = nil;
    if (originalCompletionHandler) {
      // Call original handler and hold on to its return value.
      delegate = originalCompletionHandler(ad, error);
    }

    // Release reference to handler. Objects retained by the handler will also be released.
    originalCompletionHandler = nil;

    return delegate;
  };

    NSString *parameter = adConfiguration.credentials.settings[@"parameter"];
    NSDictionary *anyManagerInfoDict = [self dictionaryWithJsonString:parameter];

    if ([anyManagerInfoDict objectForKey:@"unitId"]) {
        self.adUnit = [anyManagerInfoDict objectForKey:@"unitId"];
    }
    self.viewController =  [UIApplication sharedApplication].keyWindow.rootViewController;
    [self loadInterstitalWithRootVC: self.viewController];
}

- (void)loadInterstitalWithRootVC :(nullable UIViewController *)vc {
    
    NSString *requestId = [NSString stringWithFormat:@"%@", self.adUnit];
    self.request = [GAMRequest request];
    
    [GADRewardedAd
     loadWithAdUnitID:requestId
     request:self.request
     completionHandler:^(GADRewardedAd *rewardedAd, NSError *error) {
        if (error) {
            NSLog(@"Rewarded ad failed to load with error: %@", [error localizedDescription]);
        } else {
            if (rewardedAd) {
                self.rewardedAd = rewardedAd;
                NSLog(@"Rewarded ad loaded.");
                self.rewardedAd.fullScreenContentDelegate = self;
                self->_adEventDelegate = self->_loadCompletionHandler(self, nil);
                NSLog(@"_adEventDelegate: %@", self->_adEventDelegate);
            } else {
                NSLog(@"Ad wasn't ready");
            }
            
           
        }
        
    }];
}

#pragma mark GADMediationRewardedAd Protocol implementation

- (void)presentFromViewController:(UIViewController *)viewController {
    NSLog(@"called presentFromViewController.");
    if (self.rewardedAd) {
      [self.rewardedAd presentFromRootViewController:viewController
                                    userDidEarnRewardHandler:^{
                                  }];
        [_adEventDelegate didRewardUser];
    } else {
      NSLog(@"The Rewareded ad failed to present because the ad was not loaded.");
    }
  }

// RewardedAd Delegate

#pragma mark GADFullScreenContentDelegate Delegate implementation

/// Tells the delegate that an impression has been recorded for the ad.
- (void)adDidRecordImpression:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"adDidRecordImpression");
    [_adEventDelegate reportImpression];
}

/// Tells the delegate that a click has been recorded for the ad.
- (void)adDidRecordClick:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"adDidRecordClick");
    [_adEventDelegate reportClick];
}

/// Tells the delegate that the ad failed to present full screen content.
- (void)ad:(nonnull id<GADFullScreenPresentingAd>)ad
didFailToPresentFullScreenContentWithError:(nonnull NSError *)error {
    NSLog(@"didFailToPresentFullScreenContentWithError");
    _adEventDelegate = _loadCompletionHandler(self, error);
    [_adEventDelegate didFailToPresentWithError: error];
}

/// Tells the delegate that the ad will present full screen content.
- (void)adWillPresentFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"adWillPresentFullScreenContent");
    [_adEventDelegate willPresentFullScreenView];
}

/// Tells the delegate that the ad will dismiss full screen content.
- (void)adWillDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"adWillDismissFullScreenContent");
    [_adEventDelegate willDismissFullScreenView];
}

/// Tells the delegate that the ad dismissed full screen content.
- (void)adDidDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"adDidDismissFullScreenContent");
    [_adEventDelegate didEndVideo];
    [_adEventDelegate didDismissFullScreenView];
}

- (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err = nil;
    id result = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err];
    
    if(err == nil && [result isKindOfClass:[NSDictionary class]]) {
        
        return result;
    }
    
    return nil;
}

@end

