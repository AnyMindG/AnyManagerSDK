//
//  AnyManagerGAMCustomEvent.m
//  MyAdMobDemo
//
//  Created by Narender on 23/11/22.
//

#import <Foundation/Foundation.h>
#import "AnyManagerGAMCustomEvent.h"
#import "AnyManagerGAMCustomEventBannerAd.h"
#import "AnyManagerGAMCustomEventInterstitial.h"
#import "AnyManagerGAMCustomEventRewarded.h"
#import "AnyManagerGAMCustomEventNative.h"

#define anyManagerBannerSDKVersion  @"1.0.0"

@interface AnyManagerGAMCustomEvent () {
    
}

@property(nonatomic, strong) AnyManagerGAMCustomEventBannerAd *bannerAdView;
@property(nonatomic, strong) AnyManagerGAMCustomEventInterstitial *interstitial;
@property(nonatomic, strong) AnyManagerGAMCustomEventRewarded *rewardedAd;
@property(nonatomic, strong) AnyManagerGAMCustomEventNative *nativeAd;

@end


@implementation AnyManagerGAMCustomEvent

+ (void)setUpWithConfiguration:(nonnull GADMediationServerConfiguration *)configuration
             completionHandler:(nonnull GADMediationAdapterSetUpCompletionBlock)completionHandler{
    
    if (completionHandler) {
        completionHandler(nil);
    }
}

+ (nullable Class<GADAdNetworkExtras>)networkExtrasClass {
    return nil;
}

+ (GADVersionNumber)adSDKVersion {
    NSString *versionString = anyManagerBannerSDKVersion;
    NSArray *versionComponents = [versionString componentsSeparatedByString:@"."];
    GADVersionNumber version = {0};
    if (versionComponents.count == 3) {
        version.majorVersion = [versionComponents[0] integerValue];
        version.minorVersion = [versionComponents[1] integerValue];
        version.patchVersion = [versionComponents[2] integerValue];
    }
    return version;
}

+ (GADVersionNumber)adapterVersion {
    
    NSString *versionString = anyManagerBannerSDKVersion;
    NSArray *versionComponents = [versionString componentsSeparatedByString:@"."];
    GADVersionNumber version = {0};
    if (versionComponents.count == 4) {
        version.majorVersion = [versionComponents[0] integerValue];
        version.minorVersion = [versionComponents[1] integerValue];
        
        // Adapter versions have 2 patch versions. Multiply the first patch by 100.
        version.patchVersion = [versionComponents[2] integerValue] * 100
        + [versionComponents[3] integerValue];
    }
    return version;
}

- (void)loadBannerForAdConfiguration:(GADMediationBannerAdConfiguration *)adConfiguration
                   completionHandler:(GADMediationBannerLoadCompletionHandler)completionHandler {
    _bannerAdView = [[AnyManagerGAMCustomEventBannerAd alloc] init];
    [_bannerAdView loadBannerForAdConfiguration:adConfiguration completionHandler:completionHandler];
}

- (void)loadInterstitialForAdConfiguration:
            (GADMediationInterstitialAdConfiguration *)adConfiguration
                         completionHandler:
                             (GADMediationInterstitialLoadCompletionHandler)completionHandler {
  _interstitial = [[AnyManagerGAMCustomEventInterstitial alloc] init];
  [_interstitial loadInterstitialForAdConfiguration:adConfiguration
                                       completionHandler:completionHandler];
}

- (void)loadRewardedAdForAdConfiguration:(GADMediationRewardedAdConfiguration *)adConfiguration
                       completionHandler:
                           (GADMediationRewardedLoadCompletionHandler)completionHandler {
  _rewardedAd = [[AnyManagerGAMCustomEventRewarded alloc] init];
  [_rewardedAd loadRewardedAdForAdConfiguration:adConfiguration
                                 completionHandler:completionHandler];
}


- (void)loadNativeAdForAdConfiguration:(GADMediationNativeAdConfiguration *)adConfiguration
                     completionHandler:(GADMediationNativeLoadCompletionHandler)completionHandler {
    _nativeAd = [[AnyManagerGAMCustomEventNative alloc] init];
  [_nativeAd loadNativeAdForAdConfiguration:adConfiguration completionHandler:completionHandler];
}


@end
