//
//  AnyManagerGAMCustomEventRewarded.h
//  MyAdMobDemo
//
//  Created by Narender on 22/11/22.
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface AnyManagerGAMCustomEventRewarded : NSObject

- (void)loadRewardedAdForAdConfiguration:(GADMediationRewardedAdConfiguration *)adConfiguration
                       completionHandler:
                           (GADMediationRewardedLoadCompletionHandler)completionHandler;

@end
