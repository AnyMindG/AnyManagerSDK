//
//  AnyManagerGAMCustomEvent.h
//  MyAdMobDemo
//
//  Created by Narender on 23/11/22.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <Foundation/Foundation.h>

@interface AnyManagerGAMCustomEvent : NSObject <GADMediationAdapter> {

}

@end
