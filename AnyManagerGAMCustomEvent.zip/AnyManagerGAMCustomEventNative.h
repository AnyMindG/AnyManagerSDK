//
//  AnyManagerGAMCustomEventNative.h
//  MyAdMobDemo
//
//  Created by Narender on 23/11/22.
//

#import <Foundation/Foundation.h>
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface AnyManagerGAMCustomEventNative : NSObject
- (void)loadNativeAdForAdConfiguration:(GADMediationNativeAdConfiguration *)adConfiguration
                     completionHandler:(GADMediationNativeLoadCompletionHandler)completionHandler;
@end
