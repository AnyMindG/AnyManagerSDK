//
//  AnyManagerGAMCustomEventInterstitial.m
//  MyAdMobDemo
//
//  Created by Narender on 22/11/22.
//

#import "AnyManagerGAMCustomEventInterstitial.h"
#import <GoogleMobileAds/GADInterstitialAd.h>
#import "stdatomic.h"

#define AnyManagerBannerSDKVersion  @"1.0.0"
#define KGADInterstitialAdUnitID @"/6499/example/interstitial"

@interface AnyManagerGAMCustomEventInterstitial()<GADMediationInterstitialAd, GADFullScreenContentDelegate> {
    
    /// The completion handler to call when the ad loading succeeds or fails.
    GADMediationInterstitialLoadCompletionHandler _loadCompletionHandler;

    /// The ad event delegate to forward ad rendering events to the Google Mobile
    /// Ads SDK.
    id <GADMediationInterstitialAdEventDelegate> _adEventDelegate;
}

@property (nonatomic, copy) NSString *adUnit;
@property(nonatomic, strong) GAMRequest *request;
@property(nonatomic, strong) GAMInterstitialAd *interstitial;
@property(nonatomic, strong) UIViewController *viewController;

@end

@implementation AnyManagerGAMCustomEventInterstitial


- (void)loadInterstitialForAdConfiguration:
            (GADMediationInterstitialAdConfiguration *)adConfiguration
                         completionHandler:
                             (GADMediationInterstitialLoadCompletionHandler)
completionHandler {
    __block atomic_flag completionHandlerCalled = ATOMIC_FLAG_INIT;
    __block GADMediationInterstitialLoadCompletionHandler
    originalCompletionHandler = [completionHandler copy];
    
    _loadCompletionHandler = ^id<GADMediationInterstitialAdEventDelegate>(
                                                                          _Nullable id<GADMediationInterstitialAd> ad, NSError *_Nullable error) {
                                                                              // Only allow completion handler to be called once.
                                                                              if (atomic_flag_test_and_set(&completionHandlerCalled)) {
                                                                                  return nil;
                                                                              }
                                                                              
                                                                              id<GADMediationInterstitialAdEventDelegate> delegate = nil;
                                                                              if (originalCompletionHandler) {
                                                                                  // Call original handler and hold on to its return value.
                                                                                  delegate = originalCompletionHandler(ad, error);
                                                                              }
                                                                              
                                                                              // Release reference to handler. Objects retained by the handler will also
                                                                              // be released.
                                                                              originalCompletionHandler = nil;
                                                                              
                                                                              return delegate;
                                                                          };
    
    NSLog(@"_loadCompletionHandler %@", _loadCompletionHandler);
    
    NSString *parameter = adConfiguration.credentials.settings[@"parameter"];
    NSDictionary *anyManagerInfoDict = [self dictionaryWithJsonString:parameter];
    
    if ([anyManagerInfoDict objectForKey:@"unitId"]) {
        self.adUnit = [anyManagerInfoDict objectForKey:@"unitId"];
    }
    _viewController = adConfiguration.topViewController;
    
    [self loadInterstitalWithRootVC:self.viewController];
}

- (void)loadInterstitalWithRootVC :(nullable UIViewController *)vc {

    NSString *requestId = [NSString stringWithFormat:@"%@", self.adUnit];
    _request = [GAMRequest request];

    [GAMInterstitialAd loadWithAdManagerAdUnitID:requestId
                                         request:self.request
                               completionHandler:^(GAMInterstitialAd * _Nullable interstitialAd, NSError * _Nullable error) {
        if (error) {
            NSLog(@"[GAMInterstitialAd] load failed :%@", [error description]);
        } else {
            if (interstitialAd) {
                self.interstitial = interstitialAd;
                self.interstitial.fullScreenContentDelegate = self;
                self->_adEventDelegate = self->_loadCompletionHandler(self, nil);
                NSLog(@"_adEventDelegate: %@", self->_adEventDelegate);
            } else {
                NSLog(@"Ad wasn't ready");
            }
        }
    }];
}

// InterstitialAd Delegate

#pragma mark GADMediationInterstitialAd Protocol implementation

- (void)presentFromViewController:(UIViewController *)viewController {
    NSLog(@"presentFromViewController.");
    [self.interstitial presentFromRootViewController:viewController];
}


#pragma mark GADFullScreenContentDelegate Delegate implementation

/// Tells the delegate that an impression has been recorded for the ad.
- (void)adDidRecordImpression:(nonnull id<GADFullScreenPresentingAd>)ad {
    [_adEventDelegate reportImpression];
}

/// Tells the delegate that a click has been recorded for the ad.
- (void)adDidRecordClick:(nonnull id<GADFullScreenPresentingAd>)ad {
    [_adEventDelegate reportClick];
}

/// Tells the delegate that the ad failed to present full screen content.
- (void)ad:(nonnull id<GADFullScreenPresentingAd>)ad
didFailToPresentFullScreenContentWithError:(nonnull NSError *)error {
    _adEventDelegate = _loadCompletionHandler(nil, error);
}

/// Tells the delegate that the ad will present full screen content.
- (void)adWillPresentFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    [_adEventDelegate willPresentFullScreenView];
}

/// Tells the delegate that the ad will dismiss full screen content.
- (void)adWillDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    [_adEventDelegate willDismissFullScreenView];
}

/// Tells the delegate that the ad dismissed full screen content.
- (void)adDidDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    [_adEventDelegate didDismissFullScreenView];
}

- (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err = nil;
    id result = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err];
    
    if(err == nil && [result isKindOfClass:[NSDictionary class]]) {
        
        return result;
    }
    
    return nil;
}

@end
