//
//  AnyManagerGAMCustomEventNative.m
//  MyAdMobDemo
//
//  Created by Narender on 23/11/22.
//

#import <Foundation/Foundation.h>
#import "AnyManagerGAMCustomEventNative.h"
#include <stdatomic.h>

/// Native ad image orientation preference.
typedef NS_ENUM(NSInteger, NativeAdImageOrientation) {
  NativeAdImageOrientationAny,       ///< No orientation preference.
  NativeAdImageOrientationPortrait,  ///< Prefer portrait images.
  NativeAdImageOrientationLandscape  ///< Prefer landscape images.
};

#define AnyManagerBannerSDKVersion  @"1.0.0"

static NSString *const customEventErrorDomain = @"com.AnyMind.Group";
static NSString *const TestNativeCustomTemplateID = @"10104090";

@interface AnyManagerGAMCustomEventNative () <GADMediationNativeAd, GADNativeAdLoaderDelegate, GADNativeAdDelegate, GADAdLoaderDelegate, GADCustomNativeAdLoaderDelegate, GADVideoControllerDelegate> {

  /// The completion handler to call when the ad loading succeeds or fails.
  GADMediationNativeLoadCompletionHandler _loadCompletionHandler;

  /// The ad event delegate to forward ad rendering events to the Google Mobile Ads SDK.
  id<GADMediationNativeAdEventDelegate> _adEventDelegate;

  /// Native ad view options.
  GADNativeAdViewAdOptions *_nativeAdViewAdOptions;

  /// The native ad object
}

@property(nonatomic, strong) GADNativeAd *nativeAd;
@property(nonatomic, strong) GADAdLoader *adLoader;
@property(nonatomic, strong) GAMRequest *gamRequest;

@property(nonatomic, strong) GADRequest *gadRequest;

@property(nonatomic, strong) UIViewController *viewController;
@property(nonatomic, assign) BOOL shouldDownloadImages;
@property(nonatomic, assign) NativeAdImageOrientation preferredImageOrientation;
@property(nonatomic, assign) BOOL shouldRequestMultipleImages;

@property (nonatomic) BOOL startMuted;
@property (nonatomic, copy) NSString *adUnit;

@end

@implementation AnyManagerGAMCustomEventNative

@synthesize extraAssets;

/// Used to store the ad's images. In order to implement the GADMediationNativeAd protocol, we use
/// this class to return the images property.
NSArray<GADNativeAdImage *> *_images;

/// Used to store the ad's icon. In order to implement the GADMediationNativeAd protocol, we use
/// this class to return the icon property.
GADNativeAdImage *_icon;

/// Used to store the ad's ad choices view. In order to implement the GADMediationNativeAd protocol,
/// we use this class to return the adChoicesView property.
UIView *_adChoicesView;

//- (UIView *)mediaView {
//    return _nativeAd.mediaContent;
//}

- (nullable NSString *)headline {
  return _nativeAd.headline;
}

- (nullable NSArray<GADNativeAdImage *> *)images {
  return _nativeAd.images;
}

- (nullable NSString *)body {
  return _nativeAd.body;
}

- (nullable GADNativeAdImage *)icon {
  return _nativeAd.icon;
}

- (nullable NSString *)callToAction {
  return _nativeAd.callToAction;
}

- (nullable NSDecimalNumber *)starRating {
  return _nativeAd.starRating;
}

- (nullable NSString *)store {
  return _nativeAd.store;
}

- (nullable NSString *)price {
  return _nativeAd.price;
}

- (nullable NSString *)advertiser {
  return _nativeAd.advertiser;
}

- (nullable UIView *)adChoicesView {
  return _adChoicesView;
}

- (nullable GADMediaContent *)mediaContent {
  return _nativeAd.mediaContent;
}

- (void)loadNativeAdForAdConfiguration:
            (GADMediationNativeAdConfiguration *)adConfiguration
                     completionHandler:(GADMediationNativeLoadCompletionHandler)
                                           completionHandler {
  __block atomic_flag completionHandlerCalled = ATOMIC_FLAG_INIT;
  __block GADMediationNativeLoadCompletionHandler originalCompletionHandler =
      [completionHandler copy];

  _loadCompletionHandler = ^id<GADMediationNativeAdEventDelegate>(
      _Nullable id<GADMediationNativeAd> ad, NSError *_Nullable error) {
    // Only allow completion handler to be called once.
    if (atomic_flag_test_and_set(&completionHandlerCalled)) {
      return nil;
    }

    id<GADMediationNativeAdEventDelegate> delegate = nil;
    if (originalCompletionHandler) {
      // Call original handler and hold on to its return value.
      delegate = originalCompletionHandler(ad, error);
    }

    // Release reference to handler. Objects retained by the handler will also
    // be released.
    originalCompletionHandler = nil;

    return delegate;
  };
    
    NSString *parameter = adConfiguration.credentials.settings[@"parameter"];
    NSDictionary *anyManagerInfoDict = [self dictionaryWithJsonString:parameter];

    if ([anyManagerInfoDict objectForKey:@"unitId"]) {
        _adUnit = [anyManagerInfoDict objectForKey:@"unitId"];
    }
    
    //get video parameter
    _startMuted = NO;
    if ([anyManagerInfoDict objectForKey:@"start_muted"]) {
        _startMuted = [[anyManagerInfoDict objectForKey:@"start_muted"] boolValue];
    }
    
    GADVideoOptions *videoOptions = [[GADVideoOptions alloc] init];
    videoOptions.startMuted = _startMuted;
    
    GADNativeAdViewAdOptions *adViewOptions = [[GADNativeAdViewAdOptions alloc] init];
    adViewOptions.preferredAdChoicesPosition = GADAdChoicesPositionTopLeftCorner;
    
//    self.gamRequest = [GAMRequest request];
    self.gadRequest = [GADRequest request];
    
    self.viewController = adConfiguration.topViewController;
    
    self.adLoader = [[GADAdLoader alloc] initWithAdUnitID:_adUnit
                                       rootViewController:_viewController
                                                  adTypes: @[GADAdLoaderAdTypeNative, GADAdLoaderAdTypeCustomNative]
                                                  options:@[ videoOptions, adViewOptions ]];
    
    self.adLoader.delegate = self;
    [self.adLoader loadRequest:self.gadRequest];
    
}

#pragma mark GADAdLoaderDelegate implementation

- (void)adLoader:(GADAdLoader *)adLoader didFailToReceiveAdWithError:(NSError *)error {
  NSLog(@"%@ failed with error: %@", adLoader, [error localizedDescription]);
    _adEventDelegate = _loadCompletionHandler(self, error);
}

#pragma mark GADNativeAdLoaderDelegate implementation

- (void)adLoader:(GADAdLoader *)adLoader didReceiveNativeAd:(GADNativeAd *)nativeAd {
    NSLog(@"Received native ad: %@", nativeAd);
    nativeAd.delegate = self;
    self.nativeAd = nativeAd;
    _adEventDelegate = _loadCompletionHandler(self, nil);
}

#pragma mark GADCustomNativeAdLoaderDelegate implementation

- (void)adLoader:(nonnull GADAdLoader *)adLoader
    didReceiveCustomNativeAd:(nonnull GADCustomNativeAd *)customNativeAd {
  NSLog(@"Received custom native ad: %@", customNativeAd);
  [customNativeAd recordImpression];
}

- (nonnull NSArray<NSString *> *)customNativeAdFormatIDsForAdLoader:
    (nonnull GADAdLoader *)adLoader {
  return @[ TestNativeCustomTemplateID ];
}

#pragma mark GADVideoControllerDelegate implementation

/// Tells the delegate that the video controller has began or resumed playing a video.
- (void)videoControllerDidPlayVideo:(nonnull GADVideoController *)videoController {
    [_adEventDelegate didPlayVideo];
}

/// Tells the delegate that the video controller has paused video.
- (void)videoControllerDidPauseVideo:(nonnull GADVideoController *)videoController {
    [_adEventDelegate didPauseVideo];
}

/// Tells the delegate that the video controller's video playback has ended.
- (void)videoControllerDidEndVideoPlayback:(nonnull GADVideoController *)videoController {
    [_adEventDelegate didEndVideo];
}

/// Tells the delegate that the video controller has muted video.
- (void)videoControllerDidMuteVideo:(nonnull GADVideoController *)videoController {
    [_adEventDelegate didMuteVideo];
}

/// Tells the delegate that the video controller has unmuted video.
- (void)videoControllerDidUnmuteVideo:(nonnull GADVideoController *)videoController {
    [_adEventDelegate didUnmuteVideo];
}

#pragma mark GADNativeAdDelegate

- (void)nativeAdDidRecordClick:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate reportClick];
}

- (void)nativeAdDidRecordImpression:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate reportImpression];
}

- (void)nativeAdWillPresentScreen:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate willPresentFullScreenView];
}

- (void)nativeAdWillDismissScreen:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate willDismissFullScreenView];
}

- (void)nativeAdDidDismissScreen:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
    [_adEventDelegate didDismissFullScreenView];
}

- (void)nativeAdWillLeaveApplication:(GADNativeAd *)nativeAd {
  NSLog(@"%s", __PRETTY_FUNCTION__);
}

#pragma mark GADMediatedUnifiedNativeAd implementation

// Because the Sample SDK has click and impression tracking via methods on its native ad object
// which the developer is required to call, there's no need to pass it a reference to the UIView
// being used to display the native ad. So there's no need to implement
// mediatedNativeAd:didRenderInView:viewController:clickableAssetViews:nonClickableAssetViews here.
// If your mediated network does need a reference to the view, this method can be used to provide
// one.
// You can also access the clickable and non-clickable views by asset key if the mediation network
// needs this information.
- (void)didRenderInView:(UIView *)view
       clickableAssetViews:(NSDictionary<GADNativeAssetIdentifier, UIView *> *)clickableAssetViews
    nonclickableAssetViews:
        (NSDictionary<GADNativeAssetIdentifier, UIView *> *)nonclickableAssetViews
            viewController:(UIViewController *)viewController {
  // This method is called when the native ad view is rendered. Here you would pass the UIView back
  // to the mediated network's SDK.
  // Playing video using SampleNativeAd's playVideo method
//    [_adEventDelegate didPlayVideo];
}

- (void)didUntrackView:(UIView *)view {
  // This method is called when the mediatedNativeAd is no longer rendered in the provided view.
  // Here you would remove any tracking from the view that has mediated native ad.
}

- (void)didRecordImpression {
  
}

- (void)didRecordClickOnAssetWithName:(GADNativeAssetIdentifier)assetName
                                 view:(UIView *)view
                       viewController:(UIViewController *)viewController {

}

- (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err = nil;
    id result = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err];
    
    if(err == nil && [result isKindOfClass:[NSDictionary class]]) {
        
        return result;
    }
    
    return nil;
}

- (UIViewController*)topViewController {
    return [self topViewControllerWithRootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
}

- (UIViewController*)topViewControllerWithRootViewController:(UIViewController*)rootViewController {
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController* tabBarController = (UITabBarController*)rootViewController;
        return [self topViewControllerWithRootViewController:tabBarController.selectedViewController];
    } else if ([rootViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController* navigationController = (UINavigationController*)rootViewController;
        return [self topViewControllerWithRootViewController:navigationController.visibleViewController];
    } else if (rootViewController.presentedViewController) {
        UIViewController* presentedViewController = rootViewController.presentedViewController;
        return [self topViewControllerWithRootViewController:presentedViewController];
    } else {
        return rootViewController;
    }
}

@end
